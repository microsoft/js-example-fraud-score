x
customerid
Sys.sleep(1)
score <- customerid * 10